#include <stdio.h>
#include <malloc.h>

struct NODE
{
	struct NODE * prev;
	int data;
	struct NODE * next;
};
typedef struct NODE node;
node *head, *tail;
node* newnode(int val)
{
	int unused;
	node * t;
	t = (node*) malloc(sizeof(node));
	t->prev = NULL;
	t->next = NULL;
	t->data = val;
	return (t);
}
void insertbeg(int val)
{
	node * p;
	p = newnode(val);
	p->next = head;
	p->prev = tail;
	head = p;
}
void insertafter(int item1, int val)
{
	node *curr = head, *q;
	while (curr != NULL && curr->data != item1)
	{
		curr = curr->next;
	}
	if (curr == NULL)
	{
		printf("item not found");
	}
	else
	{
		q = newnode(val);
		q->prev = curr;
		q->next = curr->next;
		if (curr->next == NULL)
		{
			tail = curr;
		}
		else
		{
			curr->next->prev = q;
		}
		curr->next = q;
	}
}
void insertbefore(int item1, int val)
{
	node *curr = head, *temp;
	while (curr != NULL && curr->data != item1)
	{
		curr = curr->next;
	}
	if (curr == NULL)
	{
		printf("no such node");
	}
	else
	{
		temp = newnode(val);
		temp->next = curr;
		temp->prev = curr->prev;
		if (curr->prev == NULL)
		{
			head = temp;
		}
		else
		{
			curr->prev->next = temp;
		}
		curr->prev = temp;
	}
}
void insertatend(int val)
{
	node * tmp;
	tmp = newnode(val);
	if (head == 0)
	{
		head = tail = tmp;
	}
	else
	{
		tail->next = tmp;
		tmp->prev = tail;
		tail = tmp;
	}
}
void insertatpos(int pos, int value)
{
	int i = 1, j = 1;
	node *curr, *tm, *t;
	curr = head;
	while (curr != NULL)
	{
		curr = curr->next;
		i++;
	}
	if (pos > i)
	{
		printf("\ninvalid choice\n");
	}
	else if (pos == 1)
	{
		insertbeg(value);
	}
	else
	{
		tm = head;
		while (i < pos - 1)
		{
			tm = tm->next;
			j++;
		}
		t = newnode(value);
		t->prev = tm;
		t->next = tm->next;
		tm->next = t;
		t->next->prev = t;
	}
}
void insertafterpos(int pos, int value)
{
	int i = 1, j = 1;
	node *curr, *tp, *s;
	curr = head;
	while (curr != NULL)
	{
		curr = curr->next;
		i++;
	}
	if (pos > i)
	{
		printf("\ninvalid choice\n");
	}
	else if (pos == 1)
	{
		insertbeg(value);
	}
	else
	{
		tp = head;
		while (i < pos)
		{
			tp = tp->next;
			j++;
		}
		s = newnode(value);
		s->prev = tp;
		s->next = tp->next;
		tp->next = s;
		s->next->prev = s;
	}
}
void delfrombeg()
{
	node * a;
	if (head == 0)
	{
		printf("list is empty");
	}
	else
	{
		a = head;
		head = head->next;
		head->prev = NULL;
		free(a);

	}
}
void delfromend()
{
	node * b;
	if (tail == 0)
	{
		printf("list is empty");
	}
	else
	{
		b = tail;
		tail->prev->next = NULL;
		tail = tail->prev;
		free(b);
	}
}
void delatpos(int pos)
{
	int i = 1;
	node * c;
	c = head;
	while (i < pos)
	{
		c = c->next;
		i++;
	}
	c->prev->next = c->next;
	c->next->prev = c->prev;
	free(c);

}
void displayforward()
{
	node *p = head;
	while (p != NULL)
	{
		printf("%d\t", p->data);
		p = p->next;
	}
}
void displaybackward()
{
	node *p = tail;
	while (p != NULL)
	{
		printf("%d\t", p->data);
		p = p->prev;
	}
}
int main()
{
	head = NULL;
	tail = NULL;
	int ch, po, it;

	do {
		printf("\n1. insert first\n2. Insert after\n3. display \n4. insert before\n5.insertatend\n6.insertatpos\n7.insertsfterpos\n8.delfrombeg\n9.delatend\n10.delatpos\n11.displaybackward\n12.quit\n");
		scanf("%d", &ch);
		switch (ch)
		{
			case 1:
				printf("value to be inserted first:");
				scanf("%d", &po);
				insertbeg(po);
				break;
			case 2:
				printf("enter item after which an element is inserted ");
				scanf("%d", &it);
				printf("value to be inserted:");
				scanf("%d", &po);
				insertafter(it, po);
				break;
			case 4:
				printf("enter item ");
				scanf("%d", &it);
				printf("value to be inserted:");
				scanf("%d", &po);
				insertbefore(it, po);
				break;
			case 3:
				displayforward();
				break;
			case 5:
				printf("enter the value to be inserted at the end");
				scanf("%d", &it);
				insertatend(it);
				break;
			case 6:
				printf("enter pos ");
				scanf("%d", &po);
				printf("value to be inserted:");
				scanf("%d", &it);
				insertatpos(po, it);
				break;
			case 7:
				printf("enter pos to be inserted after ");
				scanf("%d", &po);
				printf("value to be inserted:");
				scanf("%d", &it);
				insertafterpos(po, it);
				break;
			case 8:
				delfrombeg();
				break;
			case 9:
				delfromend();
				break;
			case 10:
				printf("enter pos to be deleted at ");
				scanf("%d", &po);
				delatpos(po);
				break;
			case 11:
				displaybackward();
				break;
			case 12:
				break;
			default:
				printf("Invalid choice");
		}
	}	while (ch != 12);
}
