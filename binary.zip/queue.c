//simple queue
#include<stdio.h>
#include<stdlib.h>
#define max 5
int Q[max];
int f=-1,r=-1;
int isemptyQ()
{ return(f==-1);}
int isfullQ()
 { return( f==(r+1)%max);}
void insertQ(int p)
{ if(isemptyQ())
    f=r=0;
  else
     if(isfullQ())
       {printf("Error Q full"); exit(0);}
     else
      r=(r+1)%max;
  Q[r]=p;
}

 int deleteQ()
  { int p;
    if(isemptyQ())
     { printf(" Q empty ");exit(0);}
    else
      { p= Q[f];
        if(f==r)
          f=r=-1;
        else
          f=(f+1)%max;
       }
  return (p);
    }
void display()
{
    int i;
    printf("\n Elements are \n");
    for(i=f;i<max;i++)
    {
        printf("%d\n",Q[i]);
    }
}
void peek()
{
    printf("%d\n",Q[f]);
}
 void main()
       {
        int choice,ele,b;
        do
        {
         printf("\nEnter your choice\n");
         printf("\n1.insertQ\n2.deleteQ\n3.peek\n4.display\n5.exit\n");
         scanf("%d",&choice);
         switch(choice)
         {
          case 1:printf("Enter the element to be added\n");
                 scanf("%d",&ele);
                 insertQ(ele);
                 break;
          case 2:b=deleteQ();
                 
                  break;
                 
          case 3:peek();
                 
                 break;
          case 4:display();
                 
                 break;
          case 5:break;
          default:printf("invalid choice");
          }
         }
          while(choice!=5);
        }